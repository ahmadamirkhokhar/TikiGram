import os
from datetime import datetime
from functools import wraps
from uuid import uuid4

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_, and_

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
os.makedirs(INSTANCE_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = "tikigram-local-demo-change-this-secret"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(INSTANCE_DIR, "tikigram_v2.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024

db = SQLAlchemy(app)

ALLOWED = {"mp4", "webm", "mov", "m4v", "avi"}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    videos = db.relationship("Video", backref="user", lazy=True, cascade="all, delete-orphan")

class Video(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default="")
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    is_short = db.Column(db.Boolean, default=False, nullable=False)
    views = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    video_id = db.Column(db.Integer, db.ForeignKey("video.id"), nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "video_id", name="uq_like_user_video"),)

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    video_id = db.Column(db.Integer, db.ForeignKey("video.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    user = db.relationship("User")

class Follow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    following_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    __table_args__ = (db.UniqueConstraint("follower_id", "following_id", name="uq_follow_pair"),)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    text = db.Column(db.String(500), nullable=False)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

with app.app_context():
    db.create_all()


def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

@app.context_processor
def inject_user():
    return {"me": current_user()}


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Please login first.")
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper


def add_notification(user_id, text):
    if user_id:
        db.session.add(Notification(user_id=user_id, text=text))


def video_stats(video_id, uid=None):
    likes = Like.query.filter_by(video_id=video_id).count()
    comments = Comment.query.filter_by(video_id=video_id).count()
    liked = bool(Like.query.filter_by(video_id=video_id, user_id=uid).first()) if uid else False
    return likes, comments, liked

@app.route("/")
def home():
    uid = session.get("user_id")
    videos = Video.query.filter_by(is_short=False).order_by(Video.created_at.desc()).all()
    data = []
    for v in videos:
        likes, comments, liked = video_stats(v.id, uid)
        data.append({"video": v, "likes": likes, "comments": comments, "liked": liked})
    return render_template("home.html", videos=data)

@app.route("/shorts")
def shorts():
    uid = session.get("user_id")
    videos = Video.query.filter_by(is_short=True).order_by(Video.created_at.desc()).all()
    data = []
    for v in videos:
        likes, comments, liked = video_stats(v.id, uid)
        data.append({"video": v, "likes": likes, "comments": comments, "liked": liked})
    return render_template("shorts.html", videos=data)

@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        f = request.files.get("file")
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        kind = request.form.get("kind", "video")
        if not f or not f.filename:
            flash("Please choose a video file.")
            return redirect(url_for("upload"))
        ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
        if ext not in ALLOWED:
            flash("Allowed formats: MP4, WebM, MOV, M4V, AVI.")
            return redirect(url_for("upload"))
        if not title:
            flash("Please enter a title.")
            return redirect(url_for("upload"))
        safe_name = f"{uuid4().hex}.{ext}"
        f.save(os.path.join(UPLOAD_DIR, safe_name))
        v = Video(filename=safe_name, title=title, description=description, user_id=current_user().id, is_short=(kind == "short"))
        db.session.add(v)
        db.session.commit()
        flash("Uploaded successfully!")
        return redirect(url_for("shorts" if v.is_short else "video_page", video_id=v.id) if not v.is_short else url_for("shorts"))
    return render_template("upload.html")

@app.route("/video/<int:video_id>")
def video_page(video_id):
    v = db.get_or_404(Video, video_id)
    v.views += 1
    db.session.commit()
    uid = session.get("user_id")
    likes, _, liked = video_stats(v.id, uid)
    comments = Comment.query.filter_by(video_id=v.id).order_by(Comment.created_at.desc()).all()
    is_following = False
    if uid and uid != v.user_id:
        is_following = bool(Follow.query.filter_by(follower_id=uid, following_id=v.user_id).first())
    return render_template("video.html", video=v, likes=likes, liked=liked, comments=comments, is_following=is_following)

@app.route("/uploads/<path:filename>")
def uploads(filename):
    return send_from_directory(UPLOAD_DIR, filename)

@app.route("/like/<int:video_id>", methods=["POST"])
@login_required
def like(video_id):
    v = db.get_or_404(Video, video_id)
    existing = Like.query.filter_by(user_id=current_user().id, video_id=v.id).first()
    if existing:
        db.session.delete(existing)
    else:
        db.session.add(Like(user_id=current_user().id, video_id=v.id))
        if v.user_id != current_user().id:
            add_notification(v.user_id, f"@{current_user().username} liked your video: {v.title}")
    db.session.commit()
    return redirect(request.referrer or url_for("home"))

@app.route("/comment/<int:video_id>", methods=["POST"])
@login_required
def comment(video_id):
    v = db.get_or_404(Video, video_id)
    text = request.form.get("text", "").strip()
    if text:
        db.session.add(Comment(text=text, user_id=current_user().id, video_id=v.id))
        if v.user_id != current_user().id:
            add_notification(v.user_id, f"@{current_user().username} commented on your video: {v.title}")
        db.session.commit()
    return redirect(url_for("video_page", video_id=v.id))

@app.route("/follow/<int:user_id>", methods=["POST"])
@login_required
def follow(user_id):
    target = db.get_or_404(User, user_id)
    me = current_user()
    if target.id == me.id:
        return redirect(request.referrer or url_for("profile"))
    existing = Follow.query.filter_by(follower_id=me.id, following_id=target.id).first()
    if existing:
        db.session.delete(existing)
    else:
        db.session.add(Follow(follower_id=me.id, following_id=target.id))
        add_notification(target.id, f"@{me.username} started following you")
    db.session.commit()
    return redirect(request.referrer or url_for("user_profile", username=target.username))

@app.route("/profile")
@login_required
def profile():
    return render_template("profile.html", user=current_user(), videos=Video.query.filter_by(user_id=current_user().id).order_by(Video.created_at.desc()).all(), followers=Follow.query.filter_by(following_id=current_user().id).count(), following=Follow.query.filter_by(follower_id=current_user().id).count(), is_following=False, public_profile=False)

@app.route("/user/<username>")
def user_profile(username):
    u = User.query.filter_by(username=username).first_or_404()
    me = current_user()
    is_following = bool(Follow.query.filter_by(follower_id=me.id, following_id=u.id).first()) if me and me.id != u.id else False
    return render_template("profile.html", user=u, videos=Video.query.filter_by(user_id=u.id).order_by(Video.created_at.desc()).all(), followers=Follow.query.filter_by(following_id=u.id).count(), following=Follow.query.filter_by(follower_id=u.id).count(), is_following=is_following, public_profile=True)

@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    users = User.query.filter(User.username.ilike(f"%{q}%")).order_by(User.username).limit(30).all() if q else []
    videos = Video.query.filter(or_(Video.title.ilike(f"%{q}%"), Video.description.ilike(f"%{q}%"))).order_by(Video.created_at.desc()).limit(50).all() if q else []
    return render_template("search.html", q=q, users=users, videos=videos)

@app.route("/messages")
@login_required
def messages():
    q = request.args.get("q", "").strip()
    me = current_user()
    users = User.query.filter(User.id != me.id, User.username.ilike(f"%{q}%")).order_by(User.username).limit(50).all() if q else []
    return render_template("messages.html", q=q, users=users)

@app.route("/chat/<username>", methods=["GET", "POST"])
@login_required
def chat(username):
    me = current_user()
    other = User.query.filter_by(username=username).first_or_404()
    if other.id == me.id:
        return redirect(url_for("messages"))
    if request.method == "POST":
        text = request.form.get("text", "").strip()
        if text:
            db.session.add(Message(sender_id=me.id, receiver_id=other.id, text=text))
            db.session.commit()
        return redirect(url_for("chat", username=other.username))
    messages = Message.query.filter(or_(and_(Message.sender_id == me.id, Message.receiver_id == other.id), and_(Message.sender_id == other.id, Message.receiver_id == me.id))).order_by(Message.created_at.asc()).all()
    return render_template("chat.html", other_user=other, messages=messages)

@app.route("/notifications")
@login_required
def notifications():
    me = current_user()
    ns = Notification.query.filter_by(user_id=me.id).order_by(Notification.created_at.desc()).limit(100).all()
    for n in ns:
        n.is_read = True
    db.session.commit()
    return render_template("notifications.html", notifications=ns)

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if current_user():
        return redirect(url_for("home"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 4:
            flash("Username must be 3+ characters and password 4+ characters.")
            return redirect(url_for("signup"))
        if User.query.filter_by(username=username).first():
            flash("Username already exists.")
            return redirect(url_for("signup"))
        u = User(username=username, password=password)
        db.session.add(u)
        db.session.commit()
        session["user_id"] = u.id
        flash("Account created successfully!")
        return redirect(url_for("home"))
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("home"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        u = User.query.filter_by(username=username, password=password).first()
        if not u:
            flash("Invalid username or password.")
            return redirect(url_for("login"))
        session["user_id"] = u.id
        flash("Logged in successfully!")
        return redirect(request.args.get("next") or url_for("home"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.errorhandler(413)
def too_large(_):
    flash("File is too large. Maximum size is 500 MB.")
    return redirect(url_for("upload"))

if __name__ == "__main__":
    print("Tikigram is starting...")
    print("Open http://127.0.0.1:5000 in your browser.")
    app.run(host="0.0.0.0", port=5000, debug=False)
