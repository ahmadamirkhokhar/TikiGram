# Tikigram V2

A clean local Flask social-video platform with:
- Login/signup
- YouTube-style home feed
- Normal video uploads/playback
- TikTok/YouTube Shorts feed
- Likes and comments
- Views
- Follow/unfollow
- Profiles
- Search
- Private 1-to-1 messaging
- Notifications
- Responsive mobile/desktop UI

## Windows setup

1. Open CMD.
2. Enter the project folder:
   cd C:\Users\hmqas\Desktop\Tikigram_V2
3. Install packages:
   py -m pip install -r requirements.txt
4. Start:
   py app.py
5. Open:
   http://127.0.0.1:5000

The database is created automatically as `instance/tikigram_v2.db`.
This V2 does not use the old Tikgram database.

For a real public internet deployment, use a production host, persistent database, object/video storage, HTTPS, and password hashing before exposing it publicly.
